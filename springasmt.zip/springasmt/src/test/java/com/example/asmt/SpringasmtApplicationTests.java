package com.example.asmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringasmtApplicationTests {

    @Test
    void contextLoads() {
    }

}
