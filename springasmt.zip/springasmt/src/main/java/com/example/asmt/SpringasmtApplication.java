package com.example.asmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringasmtApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringasmtApplication.class, args);
    }

}
